# "Simple Weather Application using HTML, CSS &amp; JavaScript"

## Overview of Weather App

It's a  Simple Weather Application made by using HTML, CSS &amp; JavaScript.